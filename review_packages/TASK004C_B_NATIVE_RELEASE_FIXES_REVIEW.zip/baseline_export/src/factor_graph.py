from native_control.runtime import active as task004c
from task003_observer import recorder as task003
import torch
import numpy as np

from src.modules.droid_net import CorrBlock, AltCorrBlock
import src.geom.projective_ops as pops
from copy import deepcopy


class FactorGraph:
    # mainly inherited from GO-SLAM
    def __init__(self, video, update_op, device="cuda:0", corr_impl="volume", max_factors=-1):
        self.video = video
        self.update_op = update_op
        self.device = device
        self.max_factors = max_factors
        self.corr_impl = corr_impl

        # operator at 1/8 resolution
        self.ht = ht = video.ht // self.video.down_scale
        self.wd = wd = video.wd // self.video.down_scale

        self.coords0 = pops.coords_grid(ht, wd, device=device)
        self.ii = torch.as_tensor([], dtype=torch.long, device=device)
        self.jj = torch.as_tensor([], dtype=torch.long, device=device)
        self.age = torch.as_tensor([], dtype=torch.long, device=device)

        self.corr, self.net, self.inp = None, None, None
        self.damping = 1e-6 * torch.ones_like(self.video.disps)

        self.target = torch.zeros([1, 0, ht, wd, 2], device=device, dtype=torch.float)
        self.weight = torch.zeros([1, 0, ht, wd, 2], device=device, dtype=torch.float)

        # inactive factors
        self.ii_inac = torch.as_tensor([], dtype=torch.long, device=device)
        self.jj_inac = torch.as_tensor([], dtype=torch.long, device=device)
        self.ii_bad = torch.as_tensor([], dtype=torch.long, device=device)
        self.jj_bad = torch.as_tensor([], dtype=torch.long, device=device)

        self.target_inac = torch.zeros([1, 0, ht, wd, 2], device=device, dtype=torch.float)
        self.weight_inac = torch.zeros([1, 0, ht, wd, 2], device=device, dtype=torch.float)

    def __filter_repeated_edges(self, ii, jj):
        """ remove duplicate edges """
        if ii.numel() == 0:
            return ii, jj

        if self.ii.numel() == 0 and self.ii_inac.numel() == 0:
            return ii, jj

        device = ii.device

        N = max(
            self.ii.max().item() if self.ii.numel() > 0 else -1,
            self.ii_inac.max().item() if self.ii_inac.numel() > 0 else -1,
            ii.max().item()
        ) + 1

        M = max(
            self.jj.max().item() if self.jj.numel() > 0 else -1,
            self.jj_inac.max().item() if self.jj_inac.numel() > 0 else -1,
            jj.max().item()
        ) + 1

        mask = torch.zeros((N, M), dtype=torch.bool, device=device)
        mask[self.ii, self.jj] = True
        mask[self.ii_inac, self.jj_inac] = True

        keep = ~mask[ii, jj]
        return ii[keep], jj[keep]

    def print_edges(self):
        ii = self.ii.cpu().numpy()
        jj = self.jj.cpu().numpy()

        ix = np.argsort(ii)
        ii = ii[ix]
        jj = jj[ix]

        w = torch.mean(self.weight, dim=[0,2,3,4]).cpu().numpy()
        w = w[ix]
        for e in zip(ii, jj, w):
            print(e)
        print()

    def filter_edges(self):
        """ remove bad edges """
        conf = torch.mean(self.weight, dim=[0,2,3,4])
        mask = (torch.abs(self.ii-self.jj) > 2) & (conf < 0.001)
        mask = task004c().bad_edge_mask(self, mask)

        self.ii_bad = torch.cat([self.ii_bad, self.ii[mask]])
        self.jj_bad = torch.cat([self.jj_bad, self.jj[mask]])
        self.rm_factors(mask, store=False)

    def clear_edges(self):
        self.ii = None
        self.jj = None
        self.age = None
        self.corr = None
        self.damping = None
        self.net = None
        self.inp = None
        self.target = None 
        self.weight = None
        self.ii_inac = None
        self.jj_inac = None
        self.ii_bad = None
        self.jj_bad = None
        self.target_inac = None
        self.weight_inac = None

    @torch.amp.autocast('cuda',enabled=True)
    @torch.no_grad()
    def add_factors(self, ii, jj, remove=False):
        """ add edges to factor graph """

        if not isinstance(ii, torch.Tensor):
            ii = torch.as_tensor(ii, dtype=torch.long, device=self.device)

        if not isinstance(jj, torch.Tensor):
            jj = torch.as_tensor(jj, dtype=torch.long, device=self.device)

        # remove duplicate edges
        ii, jj = self.__filter_repeated_edges(ii, jj)
        if ii.shape[0] == 0:
            return

        # place limit on number of factors
        if self.max_factors > 0 and self.ii.shape[0] + ii.shape[0] > self.max_factors \
                and self.corr is not None and remove:
            
            ix = torch.arange(len(self.age))[torch.argsort(self.age).cpu()]
            self.rm_factors(ix >= self.max_factors - ii.shape[0], store=True)

        net = self.video.nets[ii].to(self.device).unsqueeze(0)

        # correlation volume for new edges
        if self.corr_impl == "volume":
            c = (ii == jj).long()
            fmap1 = self.video.fmaps[ii,0].to(self.device).unsqueeze(0)
            fmap2 = self.video.fmaps[jj,c].to(self.device).unsqueeze(0)
            corr = CorrBlock(fmap1, fmap2)
            self.corr = corr if self.corr is None else self.corr.cat(corr)

            inp = self.video.inps[ii].to(self.device).unsqueeze(0)
            self.inp = inp if self.inp is None else torch.cat([self.inp, inp], 1)

        with torch.amp.autocast('cuda', enabled=False):
            target, _ = self.video.reproject(ii, jj)
            weight = torch.zeros_like(target)

        self.ii = torch.cat([self.ii, ii], 0)
        self.jj = torch.cat([self.jj, jj], 0)
        self.age = torch.cat([self.age, torch.zeros_like(ii)], 0)

        # reprojection factors
        self.net = net if self.net is None else torch.cat([self.net, net], 1)

        self.target = torch.cat([self.target, target], 1)
        self.weight = torch.cat([self.weight, weight], 1)

    @torch.amp.autocast('cuda',enabled=True)
    def rm_factors(self, mask, store=False):
        """ drop edges from factor graph """

        # store estimated factors
        if store:
            self.ii_inac = torch.cat([self.ii_inac, self.ii[mask]], 0)
            self.jj_inac = torch.cat([self.jj_inac, self.jj[mask]], 0)
            self.target_inac = torch.cat([self.target_inac, self.target[:,mask]], 1)
            self.weight_inac = torch.cat([self.weight_inac, self.weight[:,mask]], 1)

        self.ii = self.ii[~mask]
        self.jj = self.jj[~mask]
        self.age = self.age[~mask]
        
        if self.corr_impl == "volume":
            self.corr = self.corr[~mask]

        if self.net is not None:
            self.net = self.net[:,~mask]

        if self.inp is not None:
            self.inp = self.inp[:,~mask]

        self.target = self.target[:,~mask]
        self.weight = self.weight[:,~mask]


    @torch.amp.autocast('cuda',enabled=True)
    def rm_keyframe(self, ix):
        """ drop edges from factor graph """
        with self.video.get_lock():         # clear all current kf params
            self.video.timestamp[ix] = self.video.timestamp[ix+1]
            self.video.images[ix] = self.video.images[ix+1]
            self.video.dirty[ix] = self.video.dirty[ix+1]
            self.video.npc_dirty[ix] = self.video.npc_dirty[ix+1]
            self.video.poses[ix] = self.video.poses[ix+1]
            self.video.disps[ix] = self.video.disps[ix+1]
            self.video.disps_up[ix] = self.video.disps_up[ix+1]
            self.video.intrinsics[ix] = self.video.intrinsics[ix+1]
            self.video.depth_scale[ix] = self.video.depth_scale[ix+1]
            self.video.depth_shift[ix] = self.video.depth_shift[ix+1]
            self.video.mono_disps[ix] = self.video.mono_disps[ix+1]
            self.video.mono_disps_up[ix] = self.video.mono_disps_up[ix+1]
            # self.video.mono_disps_mask_up[ix] = self.video.mono_disps_mask_up[ix+1]
            self.video.valid_depth_mask[ix] = self.video.valid_depth_mask[ix+1]
            self.video.valid_depth_mask_small[ix] = self.video.valid_depth_mask_small[ix+1]

            self.video.nets[ix] = self.video.nets[ix+1]
            self.video.inps[ix] = self.video.inps[ix+1]
            self.video.fmaps[ix] = self.video.fmaps[ix+1]

            if self.video.uncertainty_aware:
                self.video.dino_feats[ix] = self.video.dino_feats[ix+1]
                self.video.uncertainties[ix] = self.video.uncertainties[ix+1]

        m = (self.ii_inac == ix) | (self.jj_inac == ix)
        self.ii_inac[self.ii_inac >= ix] -= 1       # kfs after ix: index - 1
        self.jj_inac[self.jj_inac >= ix] -= 1

        if torch.any(m):
            self.ii_inac = self.ii_inac[~m]     # delete kf
            self.jj_inac = self.jj_inac[~m]
            self.target_inac = self.target_inac[:,~m]
            self.weight_inac = self.weight_inac[:,~m]

        m = (self.ii == ix) | (self.jj == ix)

        self.ii[self.ii >= ix] -= 1
        self.jj[self.jj >= ix] -= 1
        self.rm_factors(m, store=False)


    @torch.amp.autocast('cuda',enabled=True)
    @torch.no_grad()
    def update(self, t0=None, t1=None, itrs=2, use_inactive=False,
               EP=1e-7, motion_only=False, enable_update_uncer=True, enable_udba=True, visualization_stage=False, *, task004_phase=None):
        """ run update operator on factor graph """

        # motion features
        with torch.amp.autocast('cuda', enabled=False):
            coords1, mask = self.video.reproject(self.ii, self.jj)      # reprojected coordinates, ii->jj, [1, N, ht, wd, 2]
            motn = torch.cat([coords1 - self.coords0, self.target - coords1], dim=-1)       # projected motion + reprojected error, target: coord1 + delta
            motn = motn.permute(0,1,4,2,3).clamp(-64.0, 64.0)
        
        # correlation features
        corr = self.corr(coords1)   # [1, N, 196, ht, wd]

        self.net, delta, weight, damping, upmask = \
            self.update_op(self.net, self.inp, corr, motn, self.ii, self.jj)        # delta: predicted steps [1, N, ht, wd, 2]

        if t0 is None:
            t0 = max(1, self.ii.min().item()+1)

        with torch.amp.autocast('cuda',enabled=False):
            self.target = coords1 + delta.to(dtype=torch.float)                     # update target as the reprojected coordinates + delta
            self.weight = weight.to(dtype=torch.float)

            self.damping[torch.unique(self.ii)] = damping

            if use_inactive:
                m = (self.ii_inac >= t0 - 3) & (self.jj_inac >= t0 - 3)
                ii = torch.cat([self.ii_inac[m], self.ii], 0)
                jj = torch.cat([self.jj_inac[m], self.jj], 0)
                target = torch.cat([self.target_inac[:,m], self.target], 1)
                weight = torch.cat([self.weight_inac[:,m], self.weight], 1)

            else:
                ii, jj, target, weight = self.ii, self.jj, self.target, self.weight

            damping = .2 * self.damping[torch.unique(ii)].contiguous() + EP     # damping factor: avoid singlevalue tensor

            # bundle adjustment
            self.video.ba(target, weight, damping, ii, jj, t0, t1, 
                iters=itrs, lm=1e-4, ep=0.1, lr=self.video.cfg['tracking']['uncertainty_params']['lr'], 
                weight_decay=self.video.cfg['tracking']['uncertainty_params']['weight_decay'],
                motion_only=motion_only, 
                enable_update_uncer=enable_update_uncer, 
                enable_udba=enable_udba, 
                visualization_stage=visualization_stage, task004_phase=task004_phase)
        
            self.video.upsample(torch.unique(self.ii), upmask)

        self.age += 1


    @torch.amp.autocast('cuda',enabled=False)
    @torch.no_grad()
    def update_lowmem(self, t0=None, t1=None, itrs=2, use_inactive=False, EP=1e-7, steps=8, enable_wq=True, enable_update_uncer=True, enable_udba=True, visualization_stage=False, save_edges_weights=False):
        """ run update operator on factor graph - reduced memory implementation """

        # alternate corr implementation
        t = self.video.counter.value

        num, rig, ch, ht, wd = self.video.fmaps.shape
        corr_op = AltCorrBlock(self.video.fmaps.view(1, num*rig, ch, ht, wd))

        for step in range(steps):
            with torch.amp.autocast('cuda', enabled=False):
                coords1, mask = self.video.reproject(self.ii, self.jj)
                motn = torch.cat([coords1 - self.coords0, self.target - coords1], dim=-1)
                motn = motn.permute(0,1,4,2,3).clamp(-64.0, 64.0)
            s = 8
            for i in range(0, self.jj.max()+1, s):
                v = (self.ii >= i) & (self.ii < i + s)
                if v.sum() < 1:
                    continue
                iis = self.ii[v]
                jjs = self.jj[v]

                ht, wd = self.coords0.shape[0:2]
                corr1 = corr_op(coords1[:,v], rig * iis, rig * jjs + (iis == jjs).long())

                with torch.amp.autocast('cuda', enabled=True):
                 
                    net, delta, weight, damping, upmask = \
                        self.update_op(self.net[:,v], self.video.inps[None,iis], corr1, motn[:,v], iis, jjs)
                    self.video.upsample(torch.unique(iis), upmask)

                self.net[:,v] = net
                self.target[:,v] = coords1[:,v] + delta.float()
                self.weight[:,v] = weight.float()
                self.damping[torch.unique(iis)] = damping

            damping = .2 * self.damping[torch.unique(self.ii)].contiguous() + EP

            target = self.target
            weight = self.weight

            # dense bundle adjustment            
            task003().context(task003().stage, step+1)
            self.video.ba(target, weight, damping, self.ii, self.jj, t0, t1, 
                iters=itrs, lm=1e-5, ep=1e-2, lr=self.video.cfg['tracking']['uncertainty_params']['gba_lr'],
                weight_decay=self.video.cfg['tracking']['uncertainty_params']['gba_weight_decay'],
                motion_only=False, 
                enable_update_uncer=enable_update_uncer,
                enable_udba=enable_udba, 
                visualization_stage=visualization_stage)
        # print all edges with the format of (i, j)
        if save_edges_weights:
            print("All Edges:", [(i.item(), j.item()) for i, j in zip(self.ii, self.jj)])
            # save all weight, ii, jj to a file
            np.savez("all_edges.npz", weight=self.weight.cpu().numpy(), ii=self.ii.cpu().numpy(), jj=self.jj.cpu().numpy())


    def add_neighborhood_factors(self, t0, t1, r=3):
        """ add edges between neighboring frames within radius r """

        ii, jj = torch.meshgrid(torch.arange(t0,t1), torch.arange(t0,t1),indexing="ij")
        ii = ii.reshape(-1).to(dtype=torch.long, device=self.device)
        jj = jj.reshape(-1).to(dtype=torch.long, device=self.device)

        keep = ((ii - jj).abs() > 0) & ((ii - jj).abs() <= r)
        self.add_factors(ii[keep], jj[keep])

    
    @torch.no_grad()
    def nms_invalidate_(self, d, ii, jj, t0, t1, t, nms):
        """
        In-place: d[ (i1-t0)*(t-t1) + (j1-t1) ] = +inf
        for all (i1,j1) in L1-ball around (i,j) with radius r=clamp(|i-j|-2,0,nms),
        respecting bounds t0<=i1<t and t1<=j1<t.
        """

        device = d.device
        ii = ii.to(device=device, dtype=torch.long)
        jj = jj.to(device=device, dtype=torch.long)

        W = (t - t1)

        # radius per edge
        r = (ii - jj).abs()
        r = (r - 2).clamp(min=0, max=nms).to(torch.long)

        # precompute offsets for each radius (diamond / L1 ball)
        offsets = [None] * (nms + 1)
        offsets[0] = torch.tensor([[0, 0]], device=device, dtype=torch.long)
        for rv in range(1, nms + 1):    # rv: 1, 2, 3, ..., nms
            # all integer (di,dj) with |di|+|dj| <= rv
            di = torch.arange(-rv, rv + 1, device=device)
            dj = torch.arange(-rv, rv + 1, device=device)
            DII, DJJ = torch.meshgrid(di, dj, indexing="ij")
            m = (DII.abs() + DJJ.abs()) <= rv       # mask: [2* rv + 1, 2* rv + 1], rv: 1, 2, 3, ..., nms
            offsets[rv] = torch.stack([DII[m], DJJ[m]], dim=1).to(torch.long)  # [K,2]

        # inf = torch.tensor(float("inf"), device=device, dtype=d.dtype)

        # only loop over small number of radii
        # for all radii from 0 to nms, set the distance to inf for all edges that are within the radius
        for rv in range(0, nms + 1):
            sel = (r == rv)
            if not sel.any():
                continue

            base_i = ii[sel]  # [E]
            base_j = jj[sel]  # [E]
            off = offsets[rv] # [K,2]

            # broadcast to [E,K]
            i1 = base_i[:, None] + off[None, :, 0]
            j1 = base_j[:, None] + off[None, :, 1]

            # bounds
            m = (i1 >= t0) & (i1 < t) & (j1 >= t1) & (j1 < t)
            if not m.any():
                continue

            i1 = i1[m]
            j1 = j1[m]

            lin = (i1 - t0) * W + (j1 - t1)   # [N]
            d[lin] = np.inf  # duplicates are fine

        return d

    
    def precompute_offsets(self, nms):
        di, dj = np.meshgrid(
            np.arange(-nms, nms + 1),
            np.arange(-nms, nms + 1),
            indexing='ij'
        )
        manhattan = np.abs(di) + np.abs(dj)
        return di.flatten(), dj.flatten(), manhattan.flatten()

    
    def add_proximity_factors(self, t0=0, t1=0, rad=2, nms=2, beta=0.25, thresh=16.0, remove=False):
        """ add edges to the factor graph based on distance """

        t = self.video.counter.value
        ix = torch.arange(t0, t)
        jx = torch.arange(t1, t)

        ii, jj = torch.meshgrid(ix, jx,indexing="ij")
        ii = ii.reshape(-1)
        jj = jj.reshape(-1)

        d = self.video.distance(ii, jj, beta=beta)
        d[ii - rad < jj] = np.inf
        d[d > 100] = np.inf

        ii1 = torch.cat([self.ii, self.ii_bad, self.ii_inac], 0)
        jj1 = torch.cat([self.jj, self.jj_bad, self.jj_inac], 0)
        # non-maximum suppression based on previous edges
        d = self.nms_invalidate_(d, ii1, jj1, t0, t1, t, nms)
        
        # force to add edge within radius rad
        es = []
        for i in range(t0, t):
            for j in range(max(i-rad-1,0), i):
                es.append((i,j))
                es.append((j,i))
                d[(i-t0)*(t-t1) + (j-t1)] = np.inf

        ix = torch.argsort(d)
        for k in ix:
            if d[k].item() > thresh:
                continue
        
        # ix = torch.argsort(d)
        # d_sorted = d[ix]
        # stop = torch.searchsorted(d_sorted, torch.tensor(thresh, device=d.device, dtype=d.dtype), right=True)
        # ix = ix[:stop]                        # only candidates within threshold
        # for k in ix:

            if len(es) > self.max_factors:
                break

            i = ii[k]
            j = jj[k]
            
            # bidirectional
            es.append((i, j))
            es.append((j, i))

            # nms for newly added edges
            for di in range(-nms, nms+1):
                for dj in range(-nms, nms+1):
                    if abs(di) + abs(dj) <= max(min(abs(i-j)-2, nms), 0):
                        i1 = i + di
                        j1 = j + dj

                        if (t0 <= i1 < t) and (t1 <= j1 < t):
                            d[(i1-t0)*(t-t1) + (j1-t1)] = np.inf

        ii, jj = torch.as_tensor(es, device=self.device).unbind(dim=-1)
        self.add_factors(ii, jj, remove)


    def add_backend_proximity_factors(self, t_start, t_end, nms, radius, thresh, max_factors, beta, t_start_loop=None, loop=False):
        if t_start_loop is None or not loop:
            t_start_loop = t_start
        assert t_start_loop >= t_start, f'short: {t_start_loop}, long: {t_start}.'

        ilen = (t_end - t_start_loop)
        jlen = (t_end - t_start)
        ix = torch.arange(t_start_loop, t_end)
        jx = torch.arange(t_start, t_end)

        ii, jj = torch.meshgrid(ix, jx, indexing='ij')
        ii = ii.reshape(-1)
        jj = jj.reshape(-1)

        d = self.video.distance(ii, jj, beta=beta)
        rawd = deepcopy(d).reshape(ilen, jlen)
        d[ii - radius < jj] = np.inf
        d[d > thresh] = np.inf
        d = d.reshape(ilen, jlen)

        es = []
        # build edges within local window [i-rad, i]
        for i in range(t_start_loop, t_end):
            for j in range(max(i-radius-1, 0), i):  # j in [i-radius, i-1]
                es.append((i, j))
                es.append((j, i))
                di, dj = i-t_start_loop, j-t_start
                d[di, dj] = np.inf
                # d[max(0, di-nms):min(ilen, di+nms+1), max(0, dj-nms):min(jlen, dj+nms+1)] = np.inf

        # distance from small to big
        vals, ix = torch.sort(d.reshape(-1), descending=False)
        ix = ix[vals<=thresh]
        ix = ix.tolist()

        loop_edges = 0

        n_neighboring = 1
        for k in ix:
            di, dj = k // jlen, k % jlen
            if d[di,dj].item() > thresh:
                continue

            if len(es) > max_factors:
                break

            i = ii[k]
            j = jj[k]
            
            # bidirectional
            if loop:
                sub_es = []
                num_loop = 0
                for si in range(max(i-n_neighboring, t_start_loop), min(i+n_neighboring+1, t_end)):
                    for sj in range(max(j-n_neighboring, t_start), min(j+n_neighboring+1, t_end)):
                        if rawd[(si-t_start_loop), (sj-t_start)] <= thresh:
                            num_loop += 1
                            if si != sj and si-sj > 20:
                                sub_es += [(si, sj)]
                # if num_loop > int(((n_neighboring * 2 + 1) ** 2) * 0.5):
                es += sub_es
                loop_edges += len(sub_es)
            else:
                es += [(i, j), ]
                es += [(j, i), ]

            d[max(0, di-nms):min(ilen, di+nms+1), max(0, dj-nms):min(jlen, dj+nms+1)] = np.inf


        es, loop_edges = task004c().edge_plan(self, es, loop_edges)
        if len(es) < 3 or (loop and loop_edges==0):
            return 0

        ii, jj = torch.tensor(es, device=self.device).unbind(dim=-1)

        self.add_factors(ii, jj, remove=True)
        edge_num = len(self.ii)

        return edge_num
from native_control.install import install_factor_graph
install_factor_graph(FactorGraph)
